install.packages('rsconnect')
library(rsconnect)
rsconnect::setAccountInfo(name='mlongstreth', token='18F80761C5FACA37C2EE4D1EF129F07A', secret='S0oJjxFnobd6R8mr0Vr4oGegfVYPKCajHArTqtC/')
